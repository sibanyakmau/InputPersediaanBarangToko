package com.ta.fbasebarang;

public class MainModel {

    String nama, kode, harga, stock,aurl;

    MainModel(){

    }

    public MainModel(String nama, String kode, String harga, String stock, String aurl) {
        this.nama = nama;
        this.kode = kode;
        this.harga = harga;
        this.stock = stock;
        this.aurl = aurl;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getKode() {
        return kode;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getAurl() {
        return aurl;
    }

    public void setAurl(String aurl) {
        this.aurl = aurl;
    }
}
