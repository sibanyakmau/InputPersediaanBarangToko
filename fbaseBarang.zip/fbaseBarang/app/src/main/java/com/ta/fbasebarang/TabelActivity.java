package com.ta.fbasebarang;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class TabelActivity extends AppCompatActivity {

    private Spinner spKategori;
    private String[] pilihKategori = {
            "Pilih Kategori",
            "Sembako",
            "Perlengkapan Mandi",
            "Perlengkapan Dapur",
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tabel);

        spKategori = (Spinner) findViewById(R.id.sp_kategori);

        final ArrayAdapter<String> adapter = new ArrayAdapter<>(TabelActivity.this, android.R.layout.simple_spinner_dropdown_item, pilihKategori);
        spKategori.setAdapter(adapter);


        Button bt_alert;

        //cancel1
        bt_alert = (Button) findViewById(R.id.bt_cancel);
        bt_alert.setOnClickListener((view) -> {showDialog();});
    }

    //cancal 2
    private void showDialog(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                        this);

        //set title dialog
        alertDialogBuilder.setTitle("Yakin ingin membatalkan");

        //set pesan dari dialog
        alertDialogBuilder
                .setMessage("Klik ya untuk tetap membatalkan Input data")
                .setIcon(R.mipmap.ic_launcher)
                .setCancelable(false)

                .setPositiveButton("Ya", ((dialog, id) -> {

                    // Jika tombol di klik
                } ));
    }

    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        setContentView(R.layout.activity_hasil);
        Button tombol = findViewById(R.id.bt_submit);

        tombol.setOnClickListener((view) -> {
            Toast.makeText(getApplicationContext(), "Data telah disimpan", Toast.LENGTH_SHORT).show();
        });
    }
}