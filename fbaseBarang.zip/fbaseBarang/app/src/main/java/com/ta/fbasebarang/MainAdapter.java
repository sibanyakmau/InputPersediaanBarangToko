package com.ta.fbasebarang;

import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainAdapter extends FirebaseRecyclerAdapter<MainModel,MainAdapter.myHiewHolder> {

    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public MainAdapter(@NonNull FirebaseRecyclerOptions<MainModel> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myHiewHolder holder, final int position, @NonNull MainModel model) {
        holder.nama.setText(model.getNama());
        holder.kode.setText(model.getKode());
        holder.harga.setText(model.getHarga());
        holder.stock.setText(model.getStock());

        Glide.with(holder.img.getContext())
                .load(model.getAurl())
                .placeholder(com.google.firebase.appcheck.interop.R.drawable.common_google_signin_btn_icon_dark)
                .circleCrop()
                .error(com.google.firebase.appcheck.interop.R.drawable.common_google_signin_btn_icon_dark_normal)
                .into(holder.img);

        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final DialogPlus dialogPlus = DialogPlus.newDialog(holder.img.getContext())
                        .setContentHolder(new ViewHolder(R.layout.update_popup))
                        .setExpanded(true, 1300)
                        .create();

                //dialogPlus.show();

                View view = dialogPlus.getHolderView();

                EditText nama = view.findViewById(R.id.txtNama);
                EditText kode = view.findViewById(R.id.txtKode);
                EditText harga = view.findViewById(R.id.txtHarga);
                EditText stock = view.findViewById(R.id.txtStock);
                EditText aurl = view.findViewById(R.id.txtImageUrl);

                Button btnUpdate = view.findViewById(R.id.btnUpdate);

                nama.setText(model.getNama());
                kode.setText(model.getKode());
                harga.setText(model.getHarga());
                stock.setText(model.getStock());
                aurl.setText(model.getAurl());

                dialogPlus.show();

                btnUpdate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Map<String,Object> map = new HashMap<>();
                        map.put("nama", nama.getText().toString());
                        map.put("kode", kode.getText().toString());
                        map.put("harga", harga.getText().toString());
                        map.put("stock", stock.getText().toString());
                        map.put("aurl", aurl.getText().toString());

                        FirebaseDatabase.getInstance().getReference().child("Sembako")
                                .child(getRef(position).getKey()).updateChildren(map)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        Toast.makeText(holder.nama.getContext(), "Barang Berhasil diupdate" , Toast.LENGTH_SHORT ).show();
                                        dialogPlus.dismiss();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(holder.nama.getContext(), "Barang Gagal diupdate" , Toast.LENGTH_SHORT ).show();
                                        dialogPlus.dismiss();
                                    }
                                });
                    }
                });
            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(holder.nama.getContext());
                builder.setTitle("Apakah kamu yakin?");
                builder.setMessage("Barang yang di hapus tidak dapat di undo");

                builder.setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        FirebaseDatabase.getInstance().getReference().child("Sembako")
                                .child(getRef(position).getKey()).removeValue();
                    }
                });

                builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(holder.nama.getContext(), "Batal" , Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
            }
        });

    }

    @NonNull
    @Override
    public myHiewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.main_item,parent,false);
        return new myHiewHolder(view);
    }

    class myHiewHolder extends RecyclerView.ViewHolder{

        CircleImageView img;
        TextView nama, kode, harga, stock;

        Button btnEdit, btnDelete;

        public myHiewHolder(@NonNull View itemView) {
            super(itemView);

            img = (CircleImageView)itemView.findViewById(R.id.img1);
            nama = (TextView)itemView.findViewById(R.id.namatxt);
            kode = (TextView)itemView.findViewById(R.id.kodetxt);
            harga = (TextView)itemView.findViewById(R.id.hargatxt);
            stock = (TextView)itemView.findViewById(R.id.stocktxt);

            btnEdit = (Button)itemView.findViewById(R.id.btnEdit);
            btnDelete = (Button) itemView.findViewById(R.id.btnDelete);

        }
    }
}
